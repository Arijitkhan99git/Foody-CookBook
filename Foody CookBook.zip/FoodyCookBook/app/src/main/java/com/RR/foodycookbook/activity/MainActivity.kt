package com.RR.foodycookbook.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.FrameLayout
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import com.RR.foodycookbook.R
import com.RR.foodycookbook.fragment.DashboardFragment

class MainActivity : AppCompatActivity()
{
    lateinit var coordinatorLayout: CoordinatorLayout
    lateinit var toolbar: Toolbar
    lateinit var frameLayout: FrameLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        coordinatorLayout=findViewById(R.id.coordinateLayout)
        toolbar=findViewById(R.id.toolbar)
        frameLayout=findViewById(R.id.frame)

        supportFragmentManager.beginTransaction()
            .replace(
                R.id.frame,
                DashboardFragment()
            )
            .commit()
    }


}