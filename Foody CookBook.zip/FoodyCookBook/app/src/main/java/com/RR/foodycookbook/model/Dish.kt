package com.RR.foodycookbook.model


data class Dish(
    val dishId:String,
    val dishName:String,
    val dishImage:String
)
