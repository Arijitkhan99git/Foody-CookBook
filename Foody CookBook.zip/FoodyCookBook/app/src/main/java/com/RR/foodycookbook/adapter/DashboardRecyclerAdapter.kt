package com.RR.foodycookbook.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.RR.foodycookbook.R
import com.RR.foodycookbook.activity.DescriptionActivity
import com.RR.foodycookbook.model.Dish
import com.squareup.picasso.Picasso

class DashboardRecyclerAdapter(val context: Context,val itemList:ArrayList<Dish>):
        RecyclerView.Adapter<DashboardRecyclerAdapter.DashboardViewHolder>()
{
    class DashboardViewHolder(view: View):RecyclerView.ViewHolder(view)
    {
        var txtDishName: TextView =view.findViewById(R.id.txtDishName)
        val imgDishImage: ImageView =view.findViewById(R.id.imgDishImage)
        val llcontent: LinearLayout =view.findViewById(R.id.llcontent)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DashboardViewHolder {
        val view= LayoutInflater.from(parent.context).inflate(R.layout.recycler_dashboard_single_row,parent,false)
        return DashboardViewHolder(view)
    }

    override fun onBindViewHolder(holder: DashboardViewHolder, position: Int) {
       val dish=itemList[position]
        holder.txtDishName.text=dish.dishName

        Picasso.get().load(dish.dishImage).error(R.drawable.default_foody_cover).into(holder.imgDishImage)

        holder.llcontent.setOnClickListener {
            val intent= Intent(context, DescriptionActivity::class.java)
            intent.putExtra("dish_id",dish.dishId)
            context.startActivity(intent)
        }


    }

    override fun getItemCount(): Int {
        return itemList.size
    }

}