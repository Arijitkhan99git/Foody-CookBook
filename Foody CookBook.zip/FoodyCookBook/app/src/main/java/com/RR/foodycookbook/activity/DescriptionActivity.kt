package com.RR.foodycookbook.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.appcompat.widget.Toolbar
import com.RR.foodycookbook.R

class DescriptionActivity : AppCompatActivity() {
    lateinit var destoolbar: Toolbar
    lateinit var txtDishName: TextView
    lateinit var imgDishImage: ImageView
    lateinit var txtAboutDish: TextView
    lateinit var btnAddToFavDish: Button
    lateinit var DesProgressLayout: RelativeLayout
    lateinit var desprogressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_description)

        destoolbar=findViewById(R.id.DesToolbar)
        txtDishName=findViewById(R.id.txtDishName)
    }
}